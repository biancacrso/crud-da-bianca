ATIVIDADE PRATICA - CRUD COM PHP E POO

Tecnologias:
- PHP
- PDO
- MySQL/MariaDB
- HTML
- CSS

1. INSTALACAO NO XAMPP

Copie a pasta "meu-crud-poo" para:

C:\xampp\htdocs\

2. BANCO DE DADOS

Abra o XAMPP e inicie Apache e MySQL.

Entre no phpMyAdmin:
http://localhost/phpmyadmin

Clique em SQL e execute o conteúdo do arquivo:

database.sql

3. ACESSO

Depois de criar o banco, abra:

http://localhost/meu-crud-poo/

4. ESTRUTURA

config/Database.php
Responsável pela conexão com o banco usando PDO.

models/Produto.php
Representa o produto. Possui atributos privados e métodos getters/setters.

dao/ProdutoDAO.php
Realiza as operações do banco de dados:
- listar
- buscar
- cadastrar
- atualizar
- excluir

public/index.php
Mostra os produtos cadastrados.

public/criar.php
Formulário e processamento do cadastro.

public/editar.php
Formulário e processamento da alteração.

public/deletar.php
Processa a exclusão.

public/css/style.css
Estilos da aplicação.

index.php
Redireciona para a pasta public.

5. CRUD

CREATE - cadastro de produto
READ - listagem dos produtos
UPDATE - edição do produto
DELETE - exclusão do produto
