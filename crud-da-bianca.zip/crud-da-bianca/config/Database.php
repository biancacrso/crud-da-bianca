<?php

class Database
{
    private $host = "localhost";
    private $dbname = "crud_poo";
    private $user = "root";
    private $password = "";
    private $conn;

    public function conectar()
    {
        if ($this->conn == null) {
            try {
                $this->conn = new PDO(
                    "mysql:host={$this->host};dbname={$this->dbname};charset=utf8",
                    $this->user,
                    $this->password
                );

                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
                die("Erro ao conectar com o banco de dados: " . $e->getMessage());
            }
        }

        return $this->conn;
    }
}
