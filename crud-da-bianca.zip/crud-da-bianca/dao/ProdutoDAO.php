<?php

require_once __DIR__ . "/../config/Database.php";

class ProdutoDAO
{
    private $conexao;

    public function __construct()
    {
        $database = new Database();
        $this->conexao = $database->conectar();
    }

    public function listar()
    {
        $sql = "SELECT * FROM produtos ORDER BY id DESC";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId($id)
    {
        $sql = "SELECT * FROM produtos WHERE id = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function cadastrar(Produto $produto)
    {
        $sql = "INSERT INTO produtos (nome, preco, quantidade)
                VALUES (:nome, :preco, :quantidade)";

        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(":nome", $produto->getNome());
        $stmt->bindValue(":preco", $produto->getPreco());
        $stmt->bindValue(":quantidade", $produto->getQuantidade(), PDO::PARAM_INT);

        return $stmt->execute();
    }

    public function atualizar(Produto $produto)
    {
        $sql = "UPDATE produtos
                SET nome = :nome, preco = :preco, quantidade = :quantidade
                WHERE id = :id";

        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(":nome", $produto->getNome());
        $stmt->bindValue(":preco", $produto->getPreco());
        $stmt->bindValue(":quantidade", $produto->getQuantidade(), PDO::PARAM_INT);
        $stmt->bindValue(":id", $produto->getId(), PDO::PARAM_INT);

        return $stmt->execute();
    }

    public function excluir($id)
    {
        $sql = "DELETE FROM produtos WHERE id = :id";
        $stmt = $this->conexao->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);

        return $stmt->execute();
    }
}
