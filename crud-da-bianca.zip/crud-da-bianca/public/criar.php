<?php

require_once __DIR__ . "/../models/Produto.php";
require_once __DIR__ . "/../dao/ProdutoDAO.php";

$erro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = trim($_POST["nome"]);
    $preco = str_replace(",", ".", $_POST["preco"]);
    $quantidade = $_POST["quantidade"];

    if ($nome == "" || $preco == "" || $quantidade == "") {
        $erro = "Preencha todos os campos.";
    } elseif (!is_numeric($preco) || $preco < 0) {
        $erro = "Informe um preço válido.";
    } elseif (!is_numeric($quantidade) || $quantidade < 0) {
        $erro = "Informe uma quantidade válida.";
    } else {
        $produto = new Produto();
        $produto->setNome($nome);
        $produto->setPreco($preco);
        $produto->setQuantidade($quantidade);

        $produtoDAO = new ProdutoDAO();
        $produtoDAO->cadastrar($produto);

        header("Location: index.php?mensagem=Produto cadastrado com sucesso!");
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Produto</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="card">
        <h2>Novo Produto</h2>

        <?php if ($erro != ""): ?>
            <div class="erro"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Nome do produto</label>
            <input type="text" name="nome" maxlength="100" required>

            <label>Preço</label>
            <input type="text" name="preco" placeholder="Ex.: 25,90" required>

            <label>Quantidade</label>
            <input type="number" name="quantidade" min="0" required>

            <button class="botao" type="submit">Cadastrar</button>
            <a class="botao excluir" href="index.php">Cancelar</a>
        </form>
    </div>
</div>

</body>
</html>
