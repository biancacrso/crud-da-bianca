<?php

require_once __DIR__ . "/../dao/ProdutoDAO.php";

if (isset($_GET["id"]) && is_numeric($_GET["id"])) {
    $produtoDAO = new ProdutoDAO();
    $produtoDAO->excluir($_GET["id"]);
}

header("Location: index.php?mensagem=Produto excluído com sucesso!");
exit;
