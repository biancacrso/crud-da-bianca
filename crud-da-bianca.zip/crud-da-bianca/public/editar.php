<?php

require_once __DIR__ . "/../models/Produto.php";
require_once __DIR__ . "/../dao/ProdutoDAO.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: index.php");
    exit;
}

$id = $_GET["id"];
$produtoDAO = new ProdutoDAO();
$produtoBanco = $produtoDAO->buscarPorId($id);

if (!$produtoBanco) {
    header("Location: index.php?mensagem=Produto não encontrado.");
    exit;
}

$erro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = trim($_POST["nome"]);
    $preco = str_replace(",", ".", $_POST["preco"]);
    $quantidade = $_POST["quantidade"];

    if ($nome == "" || $preco == "" || $quantidade == "") {
        $erro = "Preencha todos os campos.";
    } elseif (!is_numeric($preco) || $preco < 0) {
        $erro = "Informe um preço válido.";
    } elseif (!is_numeric($quantidade) || $quantidade < 0) {
        $erro = "Informe uma quantidade válida.";
    } else {
        $produto = new Produto();
        $produto->setId($id);
        $produto->setNome($nome);
        $produto->setPreco($preco);
        $produto->setQuantidade($quantidade);

        $produtoDAO->atualizar($produto);

        header("Location: index.php?mensagem=Produto atualizado com sucesso!");
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="card">
        <h2>Editar Produto</h2>

        <?php if ($erro != ""): ?>
            <div class="erro"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Nome do produto</label>
            <input type="text" name="nome" maxlength="100"
                   value="<?= htmlspecialchars($produtoBanco["nome"]) ?>" required>

            <label>Preço</label>
            <input type="text" name="preco"
                   value="<?= number_format($produtoBanco["preco"], 2, ",", ".") ?>" required>

            <label>Quantidade</label>
            <input type="number" name="quantidade" min="0"
                   value="<?= $produtoBanco["quantidade"] ?>" required>

            <button class="botao" type="submit">Salvar alterações</button>
            <a class="botao excluir" href="index.php">Cancelar</a>
        </form>
    </div>
</div>

</body>
</html>
