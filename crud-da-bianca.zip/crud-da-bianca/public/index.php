<?php

require_once __DIR__ . "/../dao/ProdutoDAO.php";

$produtoDAO = new ProdutoDAO();
$produtos = $produtoDAO->listar();

$mensagem = "";
if (isset($_GET["mensagem"])) {
    $mensagem = $_GET["mensagem"];
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Produtos</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="topo">
        <h1>Cadastro de Produtos</h1>
        <a class="botao" href="criar.php">Novo produto</a>
    </div>

    <?php if ($mensagem != ""): ?>
        <div class="mensagem">
            <?= htmlspecialchars($mensagem) ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <?php if (count($produtos) == 0): ?>
            <p>Nenhum produto cadastrado.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Produto</th>
                        <th>Preço</th>
                        <th>Quantidade</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($produtos as $produto): ?>
                    <tr>
                        <td><?= $produto["id"] ?></td>
                        <td><?= htmlspecialchars($produto["nome"]) ?></td>
                        <td>R$ <?= number_format($produto["preco"], 2, ",", ".") ?></td>
                        <td><?= $produto["quantidade"] ?></td>
                        <td class="acoes">
                            <a class="botao editar" href="editar.php?id=<?= $produto["id"] ?>">Editar</a>
                            <a class="botao excluir"
                               href="deletar.php?id=<?= $produto["id"] ?>"
                               onclick="return confirm('Deseja realmente excluir este produto?');">
                               Excluir
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
